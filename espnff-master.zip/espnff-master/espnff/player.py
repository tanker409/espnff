class Player(object):
    def __init__(sef, data):
        return None
